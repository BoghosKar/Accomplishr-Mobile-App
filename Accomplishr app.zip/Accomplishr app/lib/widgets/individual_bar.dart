class IndividualBar {
  final int x;
  final int y;

  IndividualBar({required this.x, required this.y});
}
