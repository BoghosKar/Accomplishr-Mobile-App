const webScreenSize = 600;
